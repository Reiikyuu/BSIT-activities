import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("How many subjects to grade? ");

        int subjNum = scanner.nextInt();
        int[] subjCount = new int[subjNum];
        int[] grades = new int[subjNum];
        int totalGrade = 0;
        int avg = 0;
        String[] subjNames = new String[subjNum];

        System.out.println("Input " + subjNum + " subjects and their respective grades.");

        for(int i = 0; i < subjNum; i++) {
            System.out.printf("Subject #%d: ", i+1);
            subjNames[i] = scanner.next();
            System.out.print("Grade: ");
            grades[i] = scanner.nextInt();

            String letterGrade = letterGrade(grades[i]);

            System.out.println(letterGrade);

            totalGrade += grades[i];
            avg = totalGrade / subjNum;

        }
        String letterAvg = letterGrade((int) avg);
        System.out.println("The final grade is " + avg + " with a letter grade of " + letterAvg);
    }
    public static String letterGrade(int grade) {
        if (grade >= 92) {
            return "A";
        } else if (grade >= 88) {
            return "B+";
        } else if (grade >= 84) {
            return "B";
        } else if (grade >= 80) {
            return "C+";
        } else if (grade >= 76) {
            return "C";
        } else if (grade >= 72) {
            return "D";
        } else if (grade < 72) {
            return "F";
        }
        else {
            return "Invalid";
        }
    }
}