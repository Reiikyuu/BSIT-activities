import java.util.*;
import java.io.*;
import javax.swing.*;
public class Main {
    public static String toProperCase(String word) {
        return word.substring(0,1).toUpperCase().concat(word.substring(1).toLowerCase());
    }

    public static int totalGuest(int guestNum, int guestRandom1, int guestRandom2, int guestRandom3, int guestRandom4) {
        return guestNum + guestRandom1 + guestRandom2 + guestRandom3 +guestRandom4;
    }
    public static double allEarned(double guestProfit, double randomProfit1, double randomProfit2, double randomProfit3,  double randomProfit4) {
        return  randomProfit1 + randomProfit2 + randomProfit3 + randomProfit4 + guestProfit ;
    }

    public static void main(String[] args) throws FileNotFoundException{
        Random random = new Random();
        Scanner inFile = new Scanner(new FileReader("C:\\Users\\blspacanza\\Downloads\\record.txt"));
        PrintWriter outFile = new PrintWriter("C:\\Users\\blspacanza\\Downloads\\hotelBooking.txt");

        String hotelName = inFile.next();
        String address = inFile.next();
        String lotNo = inFile.next();
        String telp = inFile.next();

        String book1 = inFile.next();
        String time1 = inFile.next();
        String book2 = inFile.next();
        String time2 = inFile.next();
        String book3 = inFile.next();
        String time3 = inFile.next();
        String book4 = inFile.next();
        String time4 = inFile.next();
        String date = inFile.next();

        hotelName = hotelName.replaceAll("_", " ");
        address = address.replaceAll("_", " ");
        telp = telp.replaceAll("_", " ");
        book1 = book1.replaceAll("_", "");
        book2 = book2.replaceAll("_", "");
        book3 = book3.replaceAll("_", "");
        book4 = book4.replaceAll("_", "");
        date = date.replaceAll("_", "/");

        hotelName = toProperCase(hotelName);
        address = toProperCase(address);
        book1 = toProperCase(book1);
        book2 = toProperCase(book2);
        book3 = toProperCase(book3);
        book4 = toProperCase(book4);

        JOptionPane.showMessageDialog(null, "Welcome to " + hotelName);
        String userName = JOptionPane.showInputDialog("Enter Username: ");
        String booking = JOptionPane.showInputDialog("Room number: ");
                booking = toProperCase(booking);
        int guestNum = Integer.parseInt(JOptionPane.showInputDialog("Number of guests: "));
            guestNum = Math.abs(guestNum);
        String duration = JOptionPane.showInputDialog("Enter duration(i.e. 9:00-17:00): ");

        int guestRandom1 = random.nextInt(1, 10);
        int guestRandom2 = random.nextInt(1, 10);
        int guestRandom3 = random.nextInt(1, 10);
        int guestRandom4 = random.nextInt(1, 10);

        double randomProfit1 = guestRandom1 * 300.00;
        double randomProfit2 = guestRandom2 * 300.00;
        double randomProfit3 = guestRandom3 * 300.00;
        double randomProfit4 = guestRandom4 * 300.00;
        double guestProfit = guestNum * 300.00;
        double allEarned = allEarned(guestProfit, randomProfit1, randomProfit2, randomProfit3, randomProfit4);

        int totalGuest = totalGuest(guestRandom1, guestRandom2, guestRandom3, guestRandom4, guestNum);

        outFile.printf("%s%n" +
                        "%s, %s%n" +
                        "%s%n" +
                        "%nHotel Booking Record%n" +
                        "*******************************************************************%n" +
                        "Room\t\tParty\t\tProfit\t\t\tDuration\t\t%n" +
                        "%s\t\t%d\t\t%,.2f\t\t\t%s%n" +
                        "%s\t\t%d\t\t%,.2f\t\t\t%s%n" +
                        "%s\t\t%d\t\t%,.2f\t\t\t%s%n" +
                        "%s\t\t%d\t\t%,.2f\t\t\t%s%n" +
                        "%s\t\t%d\t\t%,.2f\t\t\t%s%n" +
                        "*******************************************************************%n" +
                        "Date: %s%n" +
                        "No. of Guests: %d%n" +
                        "Total earned: %,.2f%n" +
                        "Updated by blspacanza",hotelName, address, lotNo, telp, book1, guestRandom1, randomProfit1, time1, book2, guestRandom2, randomProfit2, time2,
                book3, guestRandom3, randomProfit3, time3, book4, guestRandom4, randomProfit4, time4, booking, guestNum, guestProfit, duration,
                date, totalGuest, allEarned);

        JOptionPane.showMessageDialog(null,"Successfully Updated!");

        inFile.close();
        outFile.close();
    }
}