/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication4;
import javax.swing.JOptionPane;
/**
 * //BONUSACT_LASTNAME
 * @author blspacanza
 */
public class JavaApplication4 {
 static void hypo (double c) {
      JOptionPane.showMessageDialog(null, "The answer is: " + c);
 }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        double a = Double.parseDouble(JOptionPane.showInputDialog("Enter a: "));
        double b = Double.parseDouble(JOptionPane.showInputDialog("Enter b: "));  
        
       hypo(a + b);
    }
    
}
