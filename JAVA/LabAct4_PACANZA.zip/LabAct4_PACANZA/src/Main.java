import java.io.*;
import java.util.*;

public class Main {
    static double average(double gr1, double gr2, double gr3) {
        return (gr1 + gr2 + gr3)/3;
    }

    static String subjects(String subj) {
        Random random = new Random();
        return subj + " " + random.nextInt(1000, 10000);
    }

    static double award(double average) {
        return Math.round(Math.abs(average * 10000));
    }

    public static void main(String[] args) throws FileNotFoundException {
        Scanner inFile = new Scanner(new FileReader("C:\\Users\\Admin\\Downloads\\LabAct4.txt"));
        String name = inFile.next().toLowerCase();
               name = name.substring(0,1).toUpperCase() + name.substring(1);
        //name = name.substring(0, name.indexOf(" ")).substring(0, 1).toUpperCase() +
                //name.substring(0, name.indexOf(" ")).substring(1).toLowerCase();
        String guild = inFile.nextLine();
               guild = guild.substring(0, 2).toUpperCase() + guild.substring(2, 11).toLowerCase() + guild.substring(11, 13).toUpperCase() + guild.substring(13).toLowerCase();
               guild = guild.replace("_", " ");
               //guild = guild.substring(12, 13).toUpperCase() + guild.substring(13).toLowerCase();
        String subj1 = inFile.next();
        String subj2 = inFile.next();
        String subj3 = inFile.next();

        double gr1 = Math.abs(inFile.nextInt());
        double gr2 = Math.abs(inFile.nextInt());
        double gr3 = Math.abs(inFile.nextInt());
        inFile.nextLine();
        String admin = inFile.next();
               admin = admin.substring(0, 1).toUpperCase() + admin.substring(1).toLowerCase();

        double average = average(gr1, gr2, gr3);
        double award = award(average);
        double max = Math.max(Math.max(gr1, gr2), gr3);

        /*String subjNum1 = subjects("Math");
        String subjNum2 = subjects("Programming");
        String subjNum3 = subjects("Robotics"); */

        PrintWriter outFile = new PrintWriter("C:\\Users\\Admin\\Downloads\\output.txt");
        outFile.printf("Welcome Everyone! \nWe are honored to have Mr. %s of%s visit the school this semester. " +
                        "In his stay here, he took three classes: %s, %s, and %s. " +
                        "His highest grade between the subjects was %.2f with an overall average of %.2f. " +
                        "For this achievement he will be awarded P%,d by the president.\n" +
                        "Yours truly,\n%s", name, guild, subjects("Math"), subjects("Programming"), subjects("Robotics"),
                max, average(gr1, gr2, gr3), (int)award, admin);

        inFile.close();
        outFile.close();
    }
}
