import javax.swing.*;
import java.util.*;
import java.io.*;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("[1] [2] [3]: ");
        String choice = scanner.nextLine();
        choice = choice.toLowerCase();
        switch (choice){
            case "1":
                System.out.println("Enter a string: ");
                String input = scanner.next();
                input = input.trim().toLowerCase();

                if (input.length() == 6) {
                    if (input.charAt(1) == 'a' || input.charAt(1) == 'e' || input.charAt(1) == 'i' || input.charAt(1) == 'o' || input.charAt(1) == 'u'
                    && input.charAt(3) == 'a' || input.charAt(3) == 'e' || input.charAt(3) == 'i' || input.charAt(3) == 'o' || input.charAt(3) == 'u') {
                        System.out.println("Congratulations!");
                        break;
                    }
                    else {
                        break;
                    }
                }
                else {
                    System.out.println("Invalid length.");
                    break;
                }
            case "2":
                System.out.println("Enter a year: ");
                int year = scanner.nextInt();
                if (year < 0) {
                    System.out.println("Invalid year.");
                    break;
                }
                else if (year % 4 == 0) {
                    System.out.println("LEAP YEAR!");
                    break;
                }
                else {
                    break;
                }

            case "3":
                System.out.println("Side A: ");
                int a = scanner.nextInt();
                System.out.println("Side B: ");
                int b = scanner.nextInt();
                System.out.println("Side C: ");
                int c = scanner.nextInt();

                if (a + b + c == 180) {
                    System.out.println("Valid Triangle");
                    break;
                }
                else {
                    System.out.println("Invalid Triangle");
                    break;
                }
            default:

                if (choice.length() >= 2 && Character.isLowerCase(choice.charAt(0)) && Character.isLowerCase(choice.charAt(choice.length()-1))) {
                    System.out.println("YES!!!");
                    break;
                }
                else {
                    System.out.println("NO!!!");
                    break;
                }

        }
    }
}