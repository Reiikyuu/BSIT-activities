/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
        
/**
 *
 * @author blspacanza
 */
public class JavaApplication1 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String name = "Bernard";
        int age = 19;
        String course = "ComProg2";
        
        System.out.println("Hello! " + name + " " + age + " years old," + " studying"
                + " in " + course);
        int num1 = 12;
        int num2 = 26;
        
        String sum = "The sum = " +(num1 + num2);
        System.out.println(sum);
    }
    
}
