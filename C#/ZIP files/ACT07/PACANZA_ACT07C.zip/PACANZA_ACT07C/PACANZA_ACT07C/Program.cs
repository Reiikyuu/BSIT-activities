﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT07C
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the value of the radius: ");
            string input = Console.ReadLine();
            double r = Convert.ToDouble(input);

            double area = Math.Round(Math.PI * Math.Pow(r, 2), 2);
            double circ = Math.Round(2 * Math.PI * r, 2);



            Console.WriteLine($"The area is " + area);
            Console.WriteLine($"The circumference is " + circ);

            Console.ReadLine();
        }
    }
}
