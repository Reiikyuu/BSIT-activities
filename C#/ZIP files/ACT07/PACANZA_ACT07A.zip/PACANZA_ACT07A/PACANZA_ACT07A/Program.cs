﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT07A
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter value of x: ");
            string input1 = Console.ReadLine();
            double x = Convert.ToDouble(input1);

            Console.Write("Enter value of y: ");
            string input2 = Console.ReadLine();
            double y = Convert.ToDouble(input2);


            int max = Math.Max(x, y);
            int min = Math.Min(x, y);
            double pow = Math.Pow(x, y);
            double sqrtRoot1 = Math.Sqrt(x);
            double sqrtRoot2 = Math.Sqrt(y);
            double absolute1 = Math.Abs(x);
            double absolute2 = Math.Abs(y);
            double ceiling1 = Math.Ceiling(sqrtRoot1);
            double floor1 = Math.Floor(sqrtRoot1);
            double round1 = Math.Round(sqrtRoot1);
            double truncate1 = Math.Truncate(sqrtRoot1);

            //Console.WriteLine("Max " + Math.Max(x, y));
            //Console.WriteLine("Min " + Math.Min(x, y));
            Console.WriteLine("Sqrt of x " + Math.Sqrt(x));
            Console.WriteLine("Abs of x " + Math.Abs(x));
            Console.WriteLine("Log " + Math.Log(x, y));
            Console.WriteLine("Round of x " + Math.Round(x)); 
            Console.WriteLine("Acos of x " + Math.Acos(x));
            Console.WriteLine("Asin of x " + Math.Asin(x));
            Console.WriteLine("Atan of x " + Math.Atan(x));
            //Console.WriteLine("Bigmul of x " + Math.BigMul(x, y)); //convert
            Console.WriteLine("Pow " + Math.Pow(x, y));
            //Console.WriteLine("Ceiling " + Math.Ceiling(x, y)); //convert
            Console.WriteLine("Truncate of x " + Math.Truncate(x)); 

            Console.ReadLine();
        }
    }
}
