﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA.ACT07D
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculating the length of the hypotenuse");
            Console.Write("Enter the first value: ");
            string input1 = Console.ReadLine();
            double a = Convert.ToDouble(input1);

            Console.Write("Enter the second value: ");
            string input2 = Console.ReadLine();
            double b = Convert.ToDouble(input2);

            double c = Math.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2));
                
            Console.WriteLine($"The hypotenuse is {c}");

            Console.ReadLine();
        }
    }
}
