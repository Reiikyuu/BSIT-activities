﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT07B
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 0;

            Console.WriteLine("x\t x^2\t x^3 + 9\t (x^4)/3)");
            Console.WriteLine("------------------------------------------");

            do
            {
                double xSquared = Math.Pow(x, 2);
                double xCubedPlus9 = Math.Pow(x, 3) + 9;
                double xToThePowerOfFourDividedByThree = Math.Pow(x, 4.0) / 3.0;

                Console.WriteLine($"{x}\t {xSquared}\t {xCubedPlus9}\t {xToThePowerOfFourDividedByThree}");
                x++;
            } while (x <= 99);

            Console.ReadLine();
        }
    }
}
