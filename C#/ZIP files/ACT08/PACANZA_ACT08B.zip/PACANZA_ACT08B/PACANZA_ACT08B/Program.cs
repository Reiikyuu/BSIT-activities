﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT08B
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            double sum = 0;
            double avg = 0;
            double[] num = new double[5];

            while (i <= 4)
            {
                Console.Write("Enter a value: ");
                num[i] = Convert.ToDouble(Console.ReadLine());
                sum += num[i];
                i++;
            }
            avg = sum / 5;
            Console.WriteLine("\nThe sum is " + sum);
            Console.WriteLine("The average is " + avg);

            int j = 0;
            Console.WriteLine("\nValues entered: ");
            while (j <= 4)
            {
                double displaynum = num[j];
                Console.WriteLine($"{displaynum}");
                j++;
            }
            Console.ReadLine();
        }
    }
}
