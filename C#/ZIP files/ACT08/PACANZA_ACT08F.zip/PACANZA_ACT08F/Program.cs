﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT08F
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] num = new double[10];
            double max = 0;
            double min = 0;

            int i = 0;
            do
            {
                Console.Write("Enter a value: ");
                num[i] = Convert.ToDouble(Console.ReadLine());
                i++;
            } while (i < 10);

            max = Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(num[0], num[1]), num[2]), num[3]), num[4]), num[5]), num[6]), num[7]), num[8]), num[9]);
            min = Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(num[0], num[1]), num[2]), num[3]), num[4]), num[5]), num[6]), num[7]), num[8]), num[9]);


            Console.WriteLine($"\nThe highest value is: {max}");
            Console.WriteLine($"The lowest value is: {min}");
            Console.ReadLine();
        }
    }
}
