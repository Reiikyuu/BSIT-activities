﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT08G
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] num = new double[10];

            double highest = num[0];
            double lowest = num[0];

            for (int i = 0; i < 10; i++)
            {
                Console.Write("Enter a value: ");
                num[i] = Convert.ToDouble(Console.ReadLine());
            }

            highest = Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(num[0], num[1]), num[2]), num[3]), num[4]), num[5]), num[6]), num[7]), num[8]), num[9]);
            lowest = Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(num[0], num[1]), num[2]), num[3]), num[4]), num[5]), num[6]), num[7]), num[8]), num[9]);

            Console.WriteLine($"\nThe highest value is: {highest}");
            Console.WriteLine($"The lowest value is: {lowest}");

            Console.ReadLine();
        }
    }
}
