﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT08D
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] num = new double[5];

            double sum = 0;
            double avg = 0;

            for (int i = 0; i <=4; i++)
            {
                Console.Write("Enter a value: ");
                num[i] = Convert.ToDouble(Console.ReadLine());
                sum += num[i];
            }

            avg = sum / 5;

            Console.WriteLine($"\nThe sum is {sum}");
            Console.WriteLine($"The average is {avg}");
            Console.WriteLine("\nValues Entered");

            for (int j = 0; j <=4; j++)
            {
                double displaynum = num[j];
                Console.WriteLine(num[j]);
            }
            Console.ReadLine();
        }
    }
}
