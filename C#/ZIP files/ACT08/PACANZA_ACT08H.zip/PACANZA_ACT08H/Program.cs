﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT08H
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[10];

            int i = 0;
            while (i < 10)
            {
                Console.Write("Enter an integer between 1-20: ");
                int input = Convert.ToInt32(Console.ReadLine());
                num[i] = input;
                i++;

            }

            Console.WriteLine("\nElement\t \tValue \tCharacter Representation");

            i = 0;
            while (i < 10)
            {
                Console.WriteLine($"{i + 1}\t \t{num[i]} \t{new string('*', num[i])}");
                i++;
            }
            Console.ReadLine();
        }
    }
}
