﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT08A
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y;

            //Declare and initialize the Array
            int[] number = new int[10];

            //Assign values to the Array
            for (int i = 0; i <10; i++)
            {
                x = i + 1;
                number[i] = x;
            }

            //Access values from the Array
            for (int j = 0; j < 10; j++)
            {
                y = number[j];
                Console.WriteLine("Element [{0}] = {1}", j, y);
            }
            Console.ReadLine();
        }
    }
}
