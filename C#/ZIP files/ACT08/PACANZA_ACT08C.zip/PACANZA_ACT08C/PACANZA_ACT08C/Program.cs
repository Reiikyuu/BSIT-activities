﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT08C
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;

            double sum = 0;
            double avg = 0;

            double[] num = new double[5];

            do
            {
                Console.Write("Enter a value: ");
                num[i] = Convert.ToDouble(Console.ReadLine());
                sum += num[i];
                i++;
            } while(i <= 4);

            avg = sum / 5;
            Console.WriteLine($"\nThe sum is {sum}");
            Console.WriteLine($"The average is {avg}");
            Console.WriteLine("\nValues entered: ");

            int j = 0;
            do
            {
                double displaynum = num[j];
                Console.WriteLine(displaynum);
                j++;
            } while (j <= 4);
            Console.ReadLine();
        }
    }
}
