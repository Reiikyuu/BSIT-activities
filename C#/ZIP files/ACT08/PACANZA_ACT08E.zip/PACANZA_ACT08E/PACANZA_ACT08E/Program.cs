﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT08E
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] num = new double[10];

            double highest = 0;
            double lowest = 0;

            int i = 0;
            while (i <10)
            {
                Console.Write("Enter a value: ");
                num[i] = Convert.ToDouble(Console.ReadLine());
                i++;
            }

            highest = Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(Math.Max(num[0], num[1]), num[2]), num[3]), num[4]), num[5]), num[6]), num[7]), num[8]), num[9]);
            lowest = Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(Math.Min(num[0], num[1]), num[2]), num[3]), num[4]), num[5]), num[6]), num[7]), num[8]), num[9]);

            Console.WriteLine($"\nThe highest value is: {highest}");
            Console.WriteLine($"The lowest value is: {lowest}");

            Console.ReadLine();
        }
    }
}
