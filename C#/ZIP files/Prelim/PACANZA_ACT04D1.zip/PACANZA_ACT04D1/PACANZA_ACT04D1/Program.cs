﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT04D1
{
    class Program
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;

            Console.Write("Enter the value of the radius of the circle: ");
            string radius_input = Console.ReadLine();

            Console.Write("Enter the value of height of the square: ");
            string height_square = Console.ReadLine();

            double radius = Convert.ToDouble(radius_input);
            int height = Convert.ToInt32(height_square);

            double area_circle = pi * (radius * radius);
            int area_square = (height * height);

            Console.WriteLine("Area of circle: {0}.", area_circle);
            Console.WriteLine("Area of square: {0}.", area_square);
            Console.ReadLine();
        }
    }
}
