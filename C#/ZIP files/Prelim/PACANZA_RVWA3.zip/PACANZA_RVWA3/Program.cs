﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_RVWA3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number between 1-12: ");
            string input = Console.ReadLine();
            int month = Convert.ToInt32(input);

            switch (month)
            {
                case 1:
                    Console.WriteLine("HAPPY NEW YEAR! ITS JANUARY");
                    break;

                case 2:
                    Console.WriteLine("HAPPY CHINESE NEW YEAR FEBUARY");
                    break;

                case 3:
                    Console.WriteLine("MARCH 7TH BIRTH MONTH");
                    break;

                case 4:
                    Console.WriteLine("APRIL FOOLS");
                    break;

                case 5:

                    Console.WriteLine("ITS SUMMER ON MAY");
                    break;
                case 6:

                    Console.WriteLine("JUNE 12 INDEPENDENCE DAY!");
                    break;
                case 7:

                    Console.WriteLine("START OF FIST SEM JULY");
                    break;

                case 8:

                    Console.WriteLine("MY BIRTH MONTH");
                    break;

                case 9:
                    Console.WriteLine("WAKE ME UP WHEN SEPTEMBER ENDS");
                    break;

                case 10:

                    Console.WriteLine("OCTOBER HALLOWEEN");
                    break;

                case 11:

                    Console.WriteLine("NO NUT NOVEMBER");
                    break;

                case 12:

                    Console.WriteLine("DECEMBER AVENUE");
                    break;

                default:
                    Console.WriteLine("Your input does not have a corresponding month");
                    break;


            }
            Console.ReadLine();
        }
    }
}
