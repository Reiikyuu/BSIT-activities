﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT05E
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please input two integer numbers");

            Console.Write("Your first number: ");
            string input1 = Console.ReadLine();
            int num1 = Convert.ToInt32(input1);

            Console.Write("Your second number: ");
            string input2 = Console.ReadLine();
            int num2 = Convert.ToInt32(input2);

            Console.WriteLine("Entered values are " + num1 + " and " + num2);

            int result = num1 / num2;
            int remainder = num1 % num2;

            Console.WriteLine("Whole number is: " + result);
            Console.WriteLine("Remainder is: " + remainder);

            if (remainder == num2)
            {
                Console.WriteLine(remainder + " is half of the value of " + num2);
            }
            else if (remainder >= num2)
            {
                Console.WriteLine(remainder + " is more than half of " + num2);
            }
            else if (remainder <= num2)
            {
                Console.WriteLine(remainder + " is less than half of " + num2);
            }
            Console.ReadLine();
        }
    }
}   
