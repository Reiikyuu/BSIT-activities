﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_RVWA04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please input a value between 30-45: ");
            string input = Console.ReadLine();
            int num = Convert.ToInt32(input);

            if (num < 30)
            {
                Console.WriteLine("Your input is not a number between 30-45.");
            }
            else if (num <= 35)
            {
                Console.WriteLine(num + " is a small number.");
            }
            else if (num <= 40)
            {
                Console.WriteLine(num + " is a medium number.");
            }
            else if (num <= 45)
            {
                Console.WriteLine(num + " is a big number.");
            }
            else
            {
                Console.WriteLine("Your input is not a number between 30-45.");
            }
            Console.ReadLine();
        }
    }
}
