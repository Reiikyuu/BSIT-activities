﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacanza_Add_ACT01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Pick a letter: ");
            string input = Console.ReadLine().ToUpper();

            switch (input)
            {
                case "A":
                Console.WriteLine("The equivalent morse code is ._");
                    break;
                case "B":
                    Console.WriteLine("The equivalent morse code is _...");
                    Console.ReadLine();
                    break;
                case "C":
                    Console.WriteLine("The equivalent morse code is _._.");
                    Console.ReadLine();
                    break;
                case "D":
                    Console.WriteLine("The equivalent morse code is _..");
                    Console.ReadLine();
                    break;
                case "E":
                    Console.WriteLine("The equivalent morse code is .");
                    Console.ReadLine();
                    break;
                case "F":
                    Console.WriteLine("The equivalent morse code is .._.");
                    Console.ReadLine();
                    break;
                case "G":
                    Console.WriteLine("The equivalent morse code is __.");
                    Console.ReadLine();
                    break;
                case "H":
                    Console.WriteLine("The equivalent morse code is ....");
                    Console.ReadLine();
                    break;
                case "I":
                    Console.WriteLine("The equivalent morse code is ..");
                    Console.ReadLine();
                    break;
                case "J":
                    Console.WriteLine("The equivalent morse code is .___");
                    Console.ReadLine();
                    break;
                case "K":
                    Console.WriteLine("The equivalent morse code is _._");
                    Console.ReadLine();
                    break;
                case "L":
                    Console.WriteLine("The equivalent morse code is ._..");
                    Console.ReadLine();
                    break;
                case "M":
                    Console.WriteLine("The equivalent morse code is __");
                    Console.ReadLine();
                    break;
                case "N":
                    Console.WriteLine("The equivalent morse code is _.");
                    break;
                case "O":
                    Console.WriteLine("The equivalent morse code is ___");
                    break;
                case "P":
                    Console.WriteLine("The equivalent morse code is .__.");
                    break;
                case "Q":
                    Console.WriteLine("The equivalent morse code is __._");
                    break;
                case "R":
                    Console.WriteLine("The equivalent morse code is._.");
                    break;
                case "S":
                    Console.WriteLine("The equivalent morse code is ...");
                    break;
                case "T":
                    Console.WriteLine("The equivalent morse code is _");
                    break;
                case "U":
                    Console.WriteLine("The equivalent morse code is .._");
                    break;
                case "V":
                    Console.WriteLine("The equivalent morse code is ..._");
                    break;
                case "W":
                    Console.WriteLine("The equivalent morse code is .__");
                    break;
                case "X":
                    Console.WriteLine("The equivalent morse code is _.._");
                    break;
                case "Y":
                    Console.WriteLine("The equivalent morse code is _.__");
                    break;
                case "Z":
                    Console.WriteLine("The equivalent morse code is__..");
                    break;
                default:
                    Console.WriteLine("You didn't pick a letter");
                    break;
            }

            Console.ReadLine();
        }
    }
}
