﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT04E1
{
    class Program
    {
        static void Main(string[] args)
        {
            const double x = 5;
            const double y = 3;

            double result = (4 * x * y) / (x * y) - (y * y) + (x - y) / (x + y);

            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
