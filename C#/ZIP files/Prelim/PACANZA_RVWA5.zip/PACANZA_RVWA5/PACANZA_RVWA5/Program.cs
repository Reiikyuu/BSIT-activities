﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_RVWA5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input a number between 30 to 45: ");
            string input = Console.ReadLine();
            int num = Convert.ToInt32(input);

            switch (num)
            {
                case int i when i <= 35:
                    Console.WriteLine(i + " is a small number");
                    break;

                case int i when i <= 40:
                    Console.WriteLine(i + " is a medium number");
                    break;

                case int i when i <= 45:
                    Console.WriteLine(i + " is a big number");
                    break;

                case int i when i < 30 | i > 45:
                    Console.WriteLine("your input is not a number between 30 - 45.");
                    break;

            }
            Console.ReadLine();
        }
    }










}
        
