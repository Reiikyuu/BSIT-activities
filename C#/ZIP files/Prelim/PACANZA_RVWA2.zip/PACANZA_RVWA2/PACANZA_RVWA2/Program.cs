﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_RVWA2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number between 1-12: ");
            string input = Console.ReadLine();
            int month = Convert.ToInt32(input);

            if (month == 1)
            {
                Console.WriteLine("HAPPY NEW YEAR! ITS JANUARY");
            }
            else if (month == 2)
            {
                Console.WriteLine("HAPPY CHINESE NEW YEAR FEBUARY");
            }
            else if (month == 3)
            {
                Console.WriteLine("MARCH 7TH BIRTH MONTH");
            }
            else if (month == 4)
            {
                Console.WriteLine("APRIL FOOLS");
            }
            else if (month == 5)
            {
                Console.WriteLine("ITS SUMMER ON MAY");
            }
            else if (month == 6)
            {
                Console.WriteLine("JUNE 12 INDEPENDENCE DAY!");
            }
            else if (month == 7)
            {
                Console.WriteLine("START OF FIST SEM JULY");
            }
            else if (month == 8)
            {
                Console.WriteLine("MY BIRTH MONTH");
            }
            else if (month == 9)
            {
                Console.WriteLine("WAKE ME UP WHEN SEPTEMBER ENDS");
            }
            else if (month == 10)
            {
                Console.WriteLine("OCTOBER HALLOWEEN");
            }
            else if (month == 11)
            {
                Console.WriteLine("NO NUT NOVEMBER");
            }
            else if (month == 12)
            {
                Console.WriteLine("DECEMBER AVENUE");
            }
            else
            {
                Console.WriteLine("Your input does not have a corresponding month");
            }
            Console.ReadLine(); 
        }
    }
}
