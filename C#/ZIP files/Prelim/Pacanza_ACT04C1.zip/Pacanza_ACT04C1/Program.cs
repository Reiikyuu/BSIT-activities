﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacanza_ACT04C1
{
    class Program
    {
        static void Main(string[] args)
        {
            string input1 = Console.ReadLine();
            string input2 = Console.ReadLine();

            int firstNum = Convert.ToInt32(input1);
            int secondNum = Convert.ToInt32(input2);

            int result1 = firstNum + secondNum;
            int result2 = firstNum - secondNum;
            int result3 = firstNum * secondNum;
            int result4 = firstNum / secondNum;
            int result5 = firstNum % secondNum;

            Console.WriteLine("Sum is {0}", result1);
            Console.WriteLine("Difference is {0}", result2);
            Console.WriteLine("Product is {0}", result3);
            Console.WriteLine("Quotient is {0}", result4);
            Console.WriteLine("Modulus is {0}", result5);

            Console.ReadLine();

        }
    }
}
