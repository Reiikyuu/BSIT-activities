﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT03B
{
    class Program
    {
        static void Main(string[] args)
        {
            int X = 20;
            Console.WriteLine("Simple Assignment: " + X);
            X += 10;
            Console.WriteLine("Add Assignment: " + X);
            X -= 15;
            Console.WriteLine("Subtract Assignment: " + X);
            X *= 2;
            Console.WriteLine("Multiply Assignment: " + X);
            X /= 4;
            Console.WriteLine("Divide Assignment: " + X);
            X %= 5;
            Console.WriteLine("Modulo Assignment: " + X);

            Console.ReadLine();


        }
    }
}
