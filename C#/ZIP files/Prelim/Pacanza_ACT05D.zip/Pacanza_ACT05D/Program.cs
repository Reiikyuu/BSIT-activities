﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacanza_ACT05D
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the first integer: ");
            string input = Console.ReadLine();
            double num1 = Convert.ToInt32(input);

            Console.Write("Enter the second integer: ");
            string input2 = Console.ReadLine();
            double num2 = Convert.ToInt32(input2);

            Console.Write("Enter operation (add, subtract, multiply, divide): ");
            string operation = Console.ReadLine().ToLower();

            double result = 0;
            bool validOperation = true;

            switch (operation)
            {
                case "add":
                    result = num1 + num2;
                    break;

                case "subtract":
                    result = num1 - num2;
                    break;

                case "multiply":
                    result = num1 * num2;
                    break;

                case "divide":
                    if (num2 == 0)
                    {
                        Console.WriteLine("Cannot divide by zero.");
                        validOperation = false;
                    }
                    else
                    {
                        result = (double)num1 / num2;
                    }
                    break;

                default:
                    Console.WriteLine("Invalid operation. Please enter a valid operation.");
                    validOperation = false;
                    break;
            }

            if (validOperation)
            {
                Console.WriteLine($"Result: {result}");
            }

            Console.WriteLine("Goodbye!");

            Console.ReadLine();
        }
    }
}
