﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT05C
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter three numbers:");

            // Input three numbers
            Console.Write("Enter the first number: ");
            double num1 = double.Parse(Console.ReadLine());

            Console.Write("Enter the second number: ");
            double num2 = double.Parse(Console.ReadLine());

            Console.Write("Enter the third number: ");
            double num3 = double.Parse(Console.ReadLine());

            // Find the highest, middle, and lowest numbers
            double highest, middle, lowest;

            if (num1 >= num2 && num1 >= num3)
            {
                highest = num1;
                if (num2 >= num3)
                {
                    middle = num2;
                    lowest = num3;
                }
                else
                {
                    middle = num3;
                    lowest = num2;
                }
            }
            else if (num2 >= num1 && num2 >= num3)
            {
                highest = num2;
                if (num1 >= num3)
                {
                    middle = num1;
                    lowest = num3;
                }
                else
                {
                    middle = num3;
                    lowest = num1;
                }
            }
            else
            {
                highest = num3;
                if (num1 >= num2)
                {
                    middle = num1;
                    lowest = num2;
                }
                else
                {
                    middle = num2;
                    lowest = num1;
                }
            }

            // Display the numbers in descending order with highest and lowest indicators
            Console.WriteLine($"Highest: {highest}");
            Console.WriteLine($"Middle: {middle}");
            Console.WriteLine($"Lowest: {lowest}");
            Console.ReadLine();
        }
    }
}

