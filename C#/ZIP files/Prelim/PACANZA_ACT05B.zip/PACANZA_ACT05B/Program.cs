﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT05B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hi there! Please enter your name: ");
            string input = Console.ReadLine();
            Console.Write("Now, enter your age: ");
            string input2 = Console.ReadLine();

            Console.WriteLine("Hi " + input);
            Console.WriteLine("Your age is " + input2);

            int age = Convert.ToInt32(input2);

            if (age > 18)
            {
                Console.WriteLine("You are of legal age!");
            }
            else
            {
                Console.WriteLine("You are a minor");
            }



            Console.ReadLine();
        }
    }
}
