﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_RVWA1
{
    class Program
    {
        static void Main(string[] args)
        {

                Console.Write("Enter the first integer: ");
                string input = Console.ReadLine();
                int num1 = Convert.ToInt32(input);

                Console.Write("Enter the second integer: ");
                string input2 = Console.ReadLine();
                int num2 = Convert.ToInt32(input2);

                Console.Write("Enter operation (add, subtract, multiply, divide): "); 
                string operation = Console.ReadLine().ToLower();

                double result = 0;
                
                switch (operation)
                {
                    case "add":
                        result = num1 + num2;
                        Console.WriteLine(result);
                        break;

                    case "subtract":
                        result = num1 - num2;
                    Console.WriteLine(result);
                    break;

                    case "multiply":
                        result = num1 * num2;
                    Console.WriteLine(result);
                    break;

                    case "divide":
                        if (num2 == 0)
                        {
                            Console.WriteLine("ERROR! Cannot divide by zero.");
                        break;
                        }
                        else
                        {
                            result = (double)num1 / num2;
                        Console.WriteLine(result);
                    }
                        break;

                    default:
                        Console.WriteLine("Invalid operation. Please enter a valid operation.");
                        break;
                }
            Console.WriteLine("Goodbye!");
            Console.ReadLine();


        }

            

            
        }
    }
