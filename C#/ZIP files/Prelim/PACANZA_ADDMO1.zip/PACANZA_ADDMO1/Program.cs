﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ADDMO1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            int i = 0;
            while (i < numbers.Length)
            {
                int j = 0;
                while (j < numbers.Length)
                {
                    Console.Write($"{numbers[i] * numbers[j]}\t");
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }
    }
}
