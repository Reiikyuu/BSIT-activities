﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_MRV1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 900;

            while (num >= 1)
            {
                if (num % 100 == 0)
                {
                    Console.WriteLine($"{num}");
                }
                num -= 1;
            }
            Console.ReadLine();
        }
    }
}
