﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_MRV08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[15];
            int product = 1;

            int i = 0;
            do
            {
                Console.Write("Enter a positive integer value: ");
                num[i] = Convert.ToInt32(Console.ReadLine());

                if (num[i] == 0)
                {
                    break;
                }
                else if (num[i] <= 0)
                {
                    Console.WriteLine("Positive integers only.");
                }
                i++;
            } while (i < 15);

            int j = 0;
            do
            {
                product *= num[j];
                j++;
            } while (j < i);

            Console.WriteLine($"The product is {product}");
            Console.ReadLine();
        }
    }
}
