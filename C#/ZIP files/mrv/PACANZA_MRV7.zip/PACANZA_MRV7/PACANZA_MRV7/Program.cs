﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_MRV7
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[15];
            int product = 1;

            int i = 0;
            while (i < 15)
            {
                    Console.Write("Enter a positive integer value: ");
                    num[i] = Convert.ToInt32(Console.ReadLine());

                if (num[i] == 0)
                {
                    break;
                }
                i++;
            }

            int j = 0;
            while (j < i)
            {
                product *= num[j];
                j++;
            }
            Console.WriteLine($"The product is {product}");
            Console.ReadLine();
        }
    }
}
