﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_MRV06
{
    internal class Program
    {
        static void Main(string[] args)
        {   
            for (int i = 0; i < 10; i++)
            {         
                Console.Write("Please Type Selection: To Degrees[D] or To Radians[R]: ");
                string input = Console.ReadLine();

                string selection = Console.ReadLine().ToUpper();
                switch (selection)
                {
                    case "D":
                        Console.Write("Please input Radian Value: ");
                        string input2 = Console.ReadLine().ToUpper();
                        double num = Convert.ToDouble(input2);
                        double degrees = num * (180 / Math.PI);

                        Console.WriteLine($"\n{num} Radians is equal to: {degrees} Degrees\n");
                        break;

                    case "R":
                        Console.Write("Please input Degree Value: ");
                        string input3 = Console.ReadLine().ToUpper();
                        double num2 = Convert.ToDouble(input3);
                        double radians = (Math.PI / 180) * num2;
                        Console.WriteLine($"\n{num2} Degrees is equal to: {radians} Radians\n");
                        break;
                    default:
                        Console.WriteLine("Only enter [R] or [D]");
                        break;
                }
            }
            Console.ReadLine();
        }
    }
}
