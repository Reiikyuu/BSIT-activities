﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_MRV09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[15];
            int product = 1;
            int count = 0;

            for (int i = 0; i < 15; i++)
            {
                Console.Write("Enter a positive integer value: ");
                int userInput = Convert.ToInt32(Console.ReadLine());

                if (userInput == 0)
                {
                    break;
                }
                else if (userInput <= 0)
                {
                    Console.WriteLine("Positive integers only.");
                    i--;
                }
                else
                {
                    num[count] = userInput;
                    count++;
                }
            }

            for (int j = 0; j < count; j++)
            {
                product *= num[j];
            }

            Console.WriteLine($"The product is {product}");
            Console.ReadLine();
        }
    }
}
