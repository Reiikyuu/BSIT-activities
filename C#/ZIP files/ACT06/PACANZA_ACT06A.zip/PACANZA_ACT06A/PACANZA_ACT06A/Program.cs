﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06A
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int w = 1;w<7; w++)
            {
                Console.WriteLine(w);
                Console.WriteLine("for loops " + w);
                //You can add statements here...
            }
            Console.WriteLine("");


            int x = 1;
            while (x<7)
            {
                Console.WriteLine(x);
                x = x + 1;
                Console.WriteLine("while loops " + x);
                //You can add statements here...
            }
            Console.WriteLine("");

            x = 1;
            do
            {
                Console.WriteLine(x);
                x = x + 1;
                Console.WriteLine("do loops " + x);
                //You can add statements here...

            } while (x < 7);
            Console.ReadLine();
        }
    }
}
