﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06D
{
    class Program
    {
        static void Main(string[] args)
        {
            


            do
            {
                Console.WriteLine("Input TEN integer numbers:");
                string input = Console.ReadLine();
                int num = Convert.ToInt32(input);

            } while ();
            int sum = sum + num;
            int avg = sum / 10;

            Console.WriteLine("The sum is " + sum);
            Console.WriteLine("The average is: " + avg);

            Console.ReadLine();
        }
    }
}
