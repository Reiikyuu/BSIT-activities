﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06L
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int count = 0;

            for (int x = 100; x <= 500; x++)
            {
                if ((x % 5 == 0 || x % 6 == 0) && !(x % 5 == 0 && x % 6 == 0))
                {
                    Console.Write($"{x}\t");
                    count++;

                    if (count == 10)
                    {
                        Console.WriteLine(); 
                        count = 0;
                    }
                }
            }
            Console.ReadLine();
        }
    }
}
