﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06F
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x = 0;

            Console.WriteLine("x\t x^2\t x^3 + 9\t (x^4)/3)");
            Console.WriteLine("-------");
            while (x <= 99)

            {
                double x2 = Math.Pow(x, 2);
                //double x2 = x ^ 2;
                double x3 = Math.Pow(x, 3) + 9;
                double x4 = Math.Pow(x, 4) / 3;
                Console.WriteLine($"{x}\t {x2}\t {x3}\t  {x4}");

                x++;
            }
            Console.ReadLine();
        }
    }
}
