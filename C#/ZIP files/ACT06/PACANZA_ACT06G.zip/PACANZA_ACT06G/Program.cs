﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06G
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("x\t x^2\t x^3 + 9\t (x^4)/3)");
            double x = 0;
            double x2 = 0;
            double x3 = 9;
            double x4 = 0;

            do
            {
                Console.WriteLine("{0}\t {1}\t {2}\t \t{3}", x, x2, x3, x4);

                x = x + 1;
                x2 = x * x;
                x3 = x * x * x + 9;
                x4 = x * x * x * x / 3;
            }
            while (x <= 99);
            Console.ReadLine();
        }
    }
}
