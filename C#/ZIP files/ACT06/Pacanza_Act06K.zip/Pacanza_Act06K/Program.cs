﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacanza_Act06K
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            int x = 100;

            do
            {
                if ((x % 5 == 0 || x % 6 == 0) && !(x % 5 == 0 && x % 6 == 0))
                {
                    Console.Write(x + "\t");
                    count++;

                    if (count == 10)
                    {
                        Console.WriteLine();
                        count = 0;
                    }
                }
                x++;
            } while (x <= 500);
            Console.ReadLine();
        }
    }
}
