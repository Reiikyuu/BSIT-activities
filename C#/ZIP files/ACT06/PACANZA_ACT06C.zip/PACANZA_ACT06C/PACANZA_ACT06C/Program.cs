﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06C
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Odd numbers from 1-21");
            for (int x = 1; x<=21; x= x+2)
            {
                Console.Write(x + " ");
            }
            Console.WriteLine("");

            Console.WriteLine("Even numbers from 2-20");
            for (int y = 2; y <= 20; y = y + 2)
            {
                Console.Write(y + " ");
            }

            Console.ReadLine();
        }
    }
}
