﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06I
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("Enter the dividend: ");
                double dividend = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter the divisor: ");
                double divisor = Convert.ToDouble(Console.ReadLine());

                double quotient = dividend / divisor;
                Console.WriteLine($"Quotient: {quotient}");

                if (quotient <= 1)
                {
                    Console.WriteLine("The quotient is not greater than 1. The program will exit.");
                    break;
                }
            }
            Console.ReadLine();
        }
        
    }
}
