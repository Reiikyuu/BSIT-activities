﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06J
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                int count = 0;
                int number = 100;

                while (number <= 500)
                {
                    if ((number % 5 == 0 || number % 6 == 0) && !(number % 5 == 0 && number % 6 == 0))
                    {
                        Console.Write($"{number}\t");
                        count++;

                        if (count == 10)
                        {
                            Console.WriteLine(); 
                            count = 0;
                        }
                    }

                    number++;
                }
                Console.ReadLine();
            }
        }

    }
}

