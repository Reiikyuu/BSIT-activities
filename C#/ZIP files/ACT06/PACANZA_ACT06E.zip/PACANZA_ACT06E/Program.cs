﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06E
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input TEN integer numbers");

            double sum = 0;
            double average = 0;

            for (int count = 0; count < 10; count++)
            {
                int numInput;
                Console.Write("Input the numbers: ");
                int.TryParse(Console.ReadLine(), out numInput);
                sum += numInput;
                average = sum / 10;


            }


            Console.WriteLine("The sum of the numbers entered is: " + sum);
            Console.WriteLine("The average of the numbers entered is: " + average);
            Console.ReadLine();
        }
    }
}
