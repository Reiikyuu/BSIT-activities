﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACANZA_ACT06B
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Odd numbers from 1-21");
            int x = 1;
            while (x <= 21)
            {
                Console.Write(x + " ");
                x = x + 2;
            }

            Console.WriteLine();

            Console.WriteLine("Even numbers from 1-20");
            int y = 2;
            while (y <=20)
            {
                Console.Write(y + " ");
                y = y + 2;
            } 

            Console.ReadLine();
        }
    }
}
